 and
 	upper(smn_base.smn_auxiliar.aux_rif) like upper(${fld:aux_rif})