 and
 	upper(smn_base.smn_auxiliar.aux_num_doc_oficial) like upper(${fld:aux_num_doc_oficial})