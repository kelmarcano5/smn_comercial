 and
 	smn_base.smn_auxiliar.aux_fecha_registro<=${fld:aux_fecha_registro_fin}