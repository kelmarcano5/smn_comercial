 and
 	upper(smn_base.smn_auxiliar.aux_apellidos) like upper(${fld:aux_apellidos})