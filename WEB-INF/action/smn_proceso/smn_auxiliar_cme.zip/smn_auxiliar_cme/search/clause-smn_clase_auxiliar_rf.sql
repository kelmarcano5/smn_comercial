 and
 	smn_base.smn_auxiliar.smn_clase_auxiliar_rf=${fld:smn_clase_auxiliar_rf}