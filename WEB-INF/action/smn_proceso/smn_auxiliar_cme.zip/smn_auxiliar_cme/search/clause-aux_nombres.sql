 and
 	upper(smn_base.smn_auxiliar.aux_nombres) like upper(${fld:aux_nombres})