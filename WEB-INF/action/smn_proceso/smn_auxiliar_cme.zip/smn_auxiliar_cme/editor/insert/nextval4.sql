select ${seq:nextval@smn_comercial.seq_smn_cliente} as id_cli
