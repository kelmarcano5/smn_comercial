select	
	*
from 
	smn_base.smn_auxiliar

where 
	smn_auxiliar_id = ${fld:id}


