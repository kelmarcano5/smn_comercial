select ${seq:nextval@smn_base.seq_smn_auxiliar_persona_contacto} as id
