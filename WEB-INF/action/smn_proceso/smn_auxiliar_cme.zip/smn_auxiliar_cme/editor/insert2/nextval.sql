select ${seq:nextval@smn_base.seq_smn_auxiliar} as id
